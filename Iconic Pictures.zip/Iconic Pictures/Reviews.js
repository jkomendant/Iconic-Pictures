$(document).ready(function(){
	
	$("#name").focus();
	
	
	
	$.getJSON("reviews.json", function(data) {
				$.each(data, function() {
					$.each(this, function(key, value) {
						$("#reviews").append(
							value.name + "<br>" + 
							value.review + "<br><br>"  
						);
					});
				}); 
			});
			
			/*
	
	$("#addReview").on('click', function(){
		var name = $("#name");
		var comments = $("#comments");
		var review = {
			name: name.val(),
			review: comments.val()
		};
		$.ajax({
			type: 'POST',
			url: 'reviews.json',
			dataType: 'json',
			data: JSON.stringify(review),
			success: function(newReview){
				$("#reviews").append(
							newReview.name + "<br>" + 
							newReview.review + "<br><br>"  
						);
			},
			error: function(){
				alert("error saving review");
			}
		});
		
	});*/
});