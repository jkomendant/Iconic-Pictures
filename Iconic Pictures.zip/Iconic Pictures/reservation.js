$(document).ready(function() {

	$("#firstName").focus();

	$(":radio").change(function() {
		var radioButton = $("#place:checked").val();
		if (radioButton == "venue") {
			$("#address").attr("disabled", false);
			$("#address").next().text("*");
			$("#city").attr("disabled", false);
			$("#city").next().text("*");
			$("#state").attr("disabled", false);
			$("#state").next().text("*");
			$("#zip").attr("disabled", false);
			$("#zip").next().text("*");
			$("#studioAddress").attr("disabled", true);
			$("#studioAddress").next().text("");
			$("#pricing").text("$500");
		} else {
			$("#address").attr("disabled", true);
			$("#address").next().text("");
			$("#city").attr("disabled", true);
			$("#city").next().text("");
			$("#state").attr("disabled", true);
			$("#state").next().text("");
			$("#zip").attr("disabled", true);
			$("#zip").next().text("");
			$("#studioAddress").attr("disabled", false);
			$("#studioAddress").next().text("*");
			$("#pricing").text("$100");
		}
		var radButton = $("#paymentType:checked").val();
		if (radButton == "creditCard") {
			$("#cardNumber").attr("disabled", false);
			$("#cardNumber").next().text("*");
			$("#cardName").attr("disabled", false);
			$("#cardName").next().text("*");
			$("#cvc").attr("disabled", false);
			$("#cvc").next().text("*");
			$("#exMonth").attr("disabled", false);
			$("#exMonth").next().text("*");
			$("#exYear").attr("disabled", false);
			$("#exYear").next().text("*");
			$("#cardType").attr("disabled", false);
			$("#cardType").next().text("*");
		} else {
			$("#cardNumber").attr("disabled", true);
			$("#cardNumber").next().text("");
			$("#cardName").attr("disabled", true);
			$("#cardName").next().text("");
			$("#cvc").attr("disabled", true);
			$("#cvc").next().text("");
			$("#exMonth").attr("disabled", true);
			$("#exMonth").next().text("");
			$("#exYear").attr("disabled", true);
			$("#exYear").next().text("");
			$("#cardType").attr("disabled", true);
			$("#cardType").next().text("");
		}

	});

	$("#datepicker").datepicker({
		minDate : new Date(),
		maxDate : +130,
		showButtonPanel : false,
		changeMonth : true,
		changeYear : true,
		inline : true
	});

	$("#setappointment").submit(function() {
		var isValid = true;

		var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
		var email = $("#emailAddress").val().trim();
		if (email == "") {
			$("#emailAddress").next().text("Required Field");
			isValid = false;
		} else if (!emailPattern.test(email)) {
			$("#emailAddress").next().text("Must be a valid email address.");
			isValid = false;
		} else {
			$("#emailAddress").next().text("");
		}
		$("#emailAddress").val(email);

		if (!$("#address").attr("disabled")) {
			var address = $("#address").val().trim();
			if (address == "") {
				$("#address").next().text("Required Field");
				isValid = false;
			} else {
				$("#address").next().text("");
			}
			$("#address").val(address);
		}

		if (!$("#city").attr("disabled")) {
			var city = $("#city").val().trim();
			if (city == "") {
				$("#city").next().text("Required Field");
				isValid = false;
			} else {
				$("#city").next().text("");
			}
			$("#city").val(city);
		}

		var firstName = $("#firstName").val().trim();
		if (firstName == "") {
			$("#firstName").next().text("Required Field");
			isValid = false;
		} else {
			$("#firstName").next().text("");
		}
		$("#firstName").val(firstName);

		var lastName = $("#lastName").val().trim();
		if (lastName == "") {
			$("#lastName").next().text("Required Field");
			isValid = false;
		} else {
			$("#lastName").next().text("");
		}
		$("#lastName").val(lastName);

		var phonePattern = /^\d{3}-\d{3}-\d{4}$/;
		var phone = $("#phoneNumber").val().trim();
		if (phone == "") {
			$("#phoneNumber").next().text("Required Field");
			isValid = false;
		} else if (!phonePattern.test(phone)) {
			$("#phoneNumber").next().text("Use 999-999-9999 format.");
			isValid = false;
		} else {
			$("#phoneNumber").next().text("");
		}
		$("#phoneNumber").val(phone);

		var occasion = $("#occasion").val();
		if (occasion == "") {
			$("#occasion").next().text("Required Field");
			isValid = false;
		} else {
			$("#occasion").next().text("");
		}
		
		var time = $("#time").val();
		if (time == "") {
			$("#time").next().text("Required Field");
			isValid = false;
		} else {
			$("#time").next().text("");
		}

		if (!$("#studioAddress").attr("disabled")) {
			var studioAddress = $("#studioAddress").val();
			if (studioAddress == "") {
				$("#studioAddress").next().text("Required Field");
				isValid = false;
			} else {
				$("#studioAddress").next().text("");
			}
			$("#studioAddress").val(studioAddress);
		}

		$("#occasion").val(occasion);

		if (!$("#occasion").attr("disabled")) {
			var occasion = $("#occasion").val();
			if (occasion == "") {
				$("#occasion").next().text("Required Field");
				isValid = false;
			} else {
				$("#occasion").next().text("");
			}
			$("#occasion").val(occasion);
		}

		if (!$("#zip").attr("disabled")) {
			var zip = $("#zip").val().trim();
			var zipPattern = /^\d{5}(-\d{4})?$/;
			if (zip == "") {
				$("#zip").next().text("Required Field");
				isValid = false;
			} else if (!zipPattern.test(zip)) {
				$("#zip").next().text("Use 99999 or 99999-9999 format.");
				isValid = false;
			} else {
				$("#zip").next().text("");
			}
			$("#zip").val(zip);
		}

		if (!$("#cardType").attr("disabled")) {
			var cardType = $("#cardType").val();
			if (cardType == "") {
				$("#cardType").next().text("Required Field");
				isValid = false;
			} else {
				$("#cardType").next().text("");
			}
			$("#cardType").val(cardType);
		}

		if (!$("#cardNumber").attr("disabled")) {
			var cardNumber = $("#cardNumber").val().trim();
			var cardPattern = /^\d{4}-\d{4}-\d{4}-\d{4}$/;
			if (cardNumber == "") {
				$("#cardNumber").next().text("Required Field");
				isValid = false;
			} else if (!cardPattern.test(cardNumber)) {
				$("#cardNumber").next().text("Use 9999-9999-9999-9999 format.");
				isValid = false;
			} else {
				$("#cardNumber").next().text("");
			}
			$("#cardNumber").val(cardNumber);
		}

		if (!$("#cvc").attr("disabled")) {
			var cvc = $("#cvc").val().trim();
			var cvcPattern = /^\d{3}(\d{1})?$/;
			if (cvc == "") {
				$("#cvc").next().text("Required Field");
				isValid = false;
			} else if (!cvcPattern.test(cvc)) {
				$("#cvc").next().text("Use 999 or 9999 format.");
				isValid = false;
			} else {
				$("#cvc").next().text("");
			}
			$("#cvc").val(cvc);
		}
					
		if (!$("#exYear").attr("disabled") && !$("#exMonth").attr("disabled")) {
			var exMonth = $("#exMonth").val();
			var exYear = $("#exYear").val();
			if (exMonth == "" && exYear !== "") {
				$("#exMonth").next().text("Required Field");
				isValid = false;
			} else if(exYear == "" && exMonth != "") {
				$("#exYear").next().text("Required Field");
				isValid = false;
			} else if(exMonth =="" && exYear ==""){
				$("#exMonth").next().text("Required Field");
				$("#exYear").next().text("Required Field");
				isValid = false;		
			}
			else {
				$("#exMonth").next().text("");
				$("#exYear").next().text("");
			}
			
			$("#exMonth").val(exMonth);
			$("#exYear").val(exYear);
		
//need to figure this out because saying datepicker is invalid date
		var today = new Date();
		var someday = new Date();
		if(exMonth == "01" || exMonth == "03" || exMonth == "05" || exMonth == "07" || exMonth == "08" || 
		exMonth == "10" || exMonth == "12"){
		someday.setFullYear(exYear, exMonth, 31);}
		else if(exMonth == "04" || exMonth == "06" || exMonth == "09" || exMonth == "11"){
		someday.setFullYear(exYear, exMonth, 30);}
		else if(exMonth == "02"){
		someday.setFullYear(exYear, exMonth, 28);}

		if (someday < today) {
			$("#exMonth").next().text("Need Valid Month");
			$("#exYear").next().text("Need Valid Year");
			return false;
		}
		}

		var date = $("#datepicker").val();
		if (date == "") {
			$("#datepicker").next().text("Required Field");
			isValid = false;
		}  else {
			$("#datepicker").next().text("");
		}
		$("#datepicker").val(date);

		if (isValid == false) {
			event.preventDefault();
		}
	});

});
