$(document).ready(function() {
			
			$("#Passaic").button();
	
			$("#Passaic").click(function() { 
				$("#dialog").dialog(					{
					modal:true
				});
			});
			
			$("#Brooklyn").button();
	
			$("#Brooklyn").click(function() { 
				$("#Bdialog").dialog(					{
					modal:true
				});
			});
			
			$("#Monsey").button();
	
			$("#Monsey").click(function() { 
				$("#Modialog").dialog(					{
					modal:true
				});
			});
			
			$("#Manhattan").button();
	
			$("#Manhattan").click(function() { 
				$("#Mdialog").dialog(					{
					modal:true
				});
			});
			
			$("#Lakewood").button();
	
			$("#Lakewood").click(function() { 
				$("#Ldialog").dialog(					{
					modal:true
				});
			});
			
			$("#Help").button();
	
			$("#Help").click(function() { 
				$("#Hdialog").dialog(					{
					modal:true
				});
			});
		});